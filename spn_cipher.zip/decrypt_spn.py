import os

ROUNDS = 10
BLOCK = 64
FILE = "cipher.txt"

SBOX = [0xE, 0x4, 0xD, 0x1, 0x2, 0xF, 0xB, 0x8,
        0x3, 0xA, 0x6, 0xC, 0x5, 0x9, 0x0, 0x7]
INV_SBOX = [0] * 16
for i in range(16):
    INV_SBOX[SBOX[i]] = i

PBOX = [(i % 8) * 8 + (i // 8) for i in range(BLOCK)]
INV_PBOX = [0] * BLOCK
for i in range(BLOCK):
    INV_PBOX[PBOX[i]] = i


def ask(prompt):
    try:
        return input(prompt)
    except (EOFError, KeyboardInterrupt):
        print()
        raise SystemExit


def round_key(key, r):
    s = (r * 8) % BLOCK
    return key[s:] + key[:s]


def xor_bits(a, b):
    return ''.join('1' if x != y else '0' for x, y in zip(a, b))


def decrypt_block(bits, key, show):
    if show:
        print(f"   вход      : {bits}")
    for r in range(ROUNDS, 0, -1):
        bits = ''.join(bits[p] for p in INV_PBOX)
        if show:
            print(f"   р{r:>2} P-box⁻¹: {bits}")
        bits = ''.join(format(INV_SBOX[int(bits[i:i + 4], 2)], '04b') for i in range(0, BLOCK, 4))
        if show:
            print(f"   р{r:>2} S-box⁻¹: {bits}")
        bits = xor_bits(bits, round_key(key, r))
        if show:
            print(f"   р{r:>2} XOR    : {bits}")
    if show:
        print(f"   открытый  : {bits}")
    return bits


def parse_cipher(s):
    s = ''.join(s.split())
    if not s:
        return None, "пустой шифртекст"
    if set(s) <= set('01') and len(s) % BLOCK == 0:
        bits = s
    else:
        if len(s) % 16 != 0:
            return None, "шифртекст должен состоять из блоков по 16 hex-цифр"
        try:
            bits = ''.join(format(int(c, 16), '04b') for c in s)
        except ValueError:
            return None, "в шифртексте есть символы, не являющиеся hex"
    return [bits[i:i + BLOCK] for i in range(0, len(bits), BLOCK)], None


def parse_key(s):
    s = ''.join(s.split())
    if set(s) <= set('01') and len(s) == BLOCK:
        return s, None
    if len(s) == 16:
        try:
            return ''.join(format(int(c, 16), '04b') for c in s), None
        except ValueError:
            pass
    return None, "ключ должен быть 64 бита (0/1) или 16 hex-цифр"


def read_file():
    if not os.path.exists(FILE):
        return None, None, f"файл {FILE} не найден — сначала запустите encrypt_spn.py"
    key = hexs = None
    for line in open(FILE, encoding="utf-8"):
        if line.startswith("key:"):
            key = line[4:].strip()
        if line.startswith("hex:"):
            hexs = line[4:].strip()
    if not key or not hexs:
        return None, None, f"в файле {FILE} нет строк key: и hex:"
    return key, hexs, None


def blocks_to_text(blocks):
    bits = ''.join(blocks)
    data = bytes(int(bits[i:i + 8], 2) for i in range(0, len(bits), 8))
    pad = data[-1]
    if pad < 1 or pad > 8 or data[-pad:] != bytes([pad]) * pad:
        return data, "дополнение PKCS#7 не сошлось — неверный ключ или вставлен не весь шифртекст"
    try:
        return data[:-pad].decode('utf-8'), None
    except UnicodeDecodeError:
        return data[:-pad], "байты не читаются как UTF-8 — скорее всего неверный ключ"


print("Дешифратор SPN")
print()

while True:
    answer = ask(f"Шифртекст (Enter — взять из {FILE}) : ").strip()

    if answer == "":
        key, hexs, err = read_file()
        if err:
            print("Ошибка:", err)
            print()
            continue
        blocks, err = parse_cipher(hexs)
        if err:
            print("Ошибка:", err)
            print()
            continue
        print(f"Прочитано из {FILE}, ключ: {key}")
    else:
        blocks, err = parse_cipher(answer)
        if err:
            print("Ошибка:", err)
            print()
            continue
        key, err = parse_key(ask("Ключ (64 бита или 16 hex)           : "))
        if err:
            print("Ошибка:", err)
            print()
            continue

    show = ask("Показать раунды? (д/н)              : ").strip().lower() in ("д", "да", "y", "yes", "1")

    print()
    print("Блоков        :", len(blocks))
    print()
    print("Дешифрование:")
    dec = []
    for i, b in enumerate(blocks, 1):
        if show:
            print(f"Блок {i}:")
        dec.append(decrypt_block(b, key, show))
    if not show:
        print("   готово, блоков:", len(dec))
    print()

    result, warn = blocks_to_text(dec)
    if warn:
        print("Внимание      :", warn)
        print("Байты         :", result.hex(' '))
        print("Как текст     :", result.decode('utf-8', errors='replace'))
    else:
        print("Открытый текст:")
        print(result)

    print()
    if ask("Ещё раз? (д/н)                      : ").strip().lower() not in ("д", "да", "y", "yes", "1"):
        break
    print()
