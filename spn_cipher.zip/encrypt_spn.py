import random

ROUNDS = 10
BLOCK = 64
FILE = "cipher.txt"

SBOX = [0xE, 0x4, 0xD, 0x1, 0x2, 0xF, 0xB, 0x8,
        0x3, 0xA, 0x6, 0xC, 0x5, 0x9, 0x0, 0x7]

PBOX = [(i % 8) * 8 + (i // 8) for i in range(BLOCK)]


def ask(prompt):
    try:
        return input(prompt)
    except (EOFError, KeyboardInterrupt):
        print()
        raise SystemExit


def round_key(key, r):
    s = (r * 8) % BLOCK
    return key[s:] + key[:s]


def xor_bits(a, b):
    return ''.join('1' if x != y else '0' for x, y in zip(a, b))


def encrypt_block(bits, key, show):
    if show:
        print(f"   вход      : {bits}")
    for r in range(1, ROUNDS + 1):
        bits = xor_bits(bits, round_key(key, r))
        if show:
            print(f"   р{r:>2} XOR   : {bits}")
        bits = ''.join(format(SBOX[int(bits[i:i + 4], 2)], '04b') for i in range(0, BLOCK, 4))
        if show:
            print(f"   р{r:>2} S-box : {bits}")
        bits = ''.join(bits[p] for p in PBOX)
        if show:
            print(f"   р{r:>2} P-box : {bits}")
    if show:
        print(f"   шифртекст : {bits}")
    return bits


def text_to_blocks(text):
    data = text.encode('utf-8')
    pad = 8 - len(data) % 8
    data += bytes([pad]) * pad
    bits = ''.join(format(c, '08b') for c in data)
    return [bits[i:i + BLOCK] for i in range(0, len(bits), BLOCK)]


def to_hex(blocks):
    return ' '.join(format(int(b, 2), '016x') for b in blocks)


def parse_key(s):
    s = ''.join(s.split())
    if set(s) <= set('01') and len(s) == BLOCK:
        return s, None
    if len(s) == 16:
        try:
            return ''.join(format(int(c, 16), '04b') for c in s), None
        except ValueError:
            pass
    return None, "ключ должен быть 64 бита (0/1) или 16 hex-цифр"


print("Шифратор SPN")
print()
print("Введите текст. Пустая строка — конец ввода.")

lines = []
while True:
    line = ask("> ")
    if line == "":
        break
    lines.append(line)

text = "\n".join(lines)
if not text:
    print("Текст пустой, шифровать нечего.")
    raise SystemExit

answer = ask("Ключ (Enter — случайный) : ").strip()
if answer == "":
    key = ''.join(random.choice('01') for _ in range(BLOCK))
else:
    key, err = parse_key(answer)
    if err:
        print("Ошибка:", err)
        raise SystemExit

show = ask("Показать раунды? (д/н)   : ").strip().lower() in ("д", "да", "y", "yes", "1")
blocks = text_to_blocks(text)

print()
print("Исходный текст:")
print(text)
print()
print("Символов      :", len(text))
print("Байт (UTF-8)  :", len(text.encode('utf-8')))
print("Блоков по 64  :", len(blocks))
print("Ключ          :", key)
print()

print("Шифрование:")
enc = []
for i, b in enumerate(blocks, 1):
    if show:
        print(f"Блок {i}:")
    enc.append(encrypt_block(b, key, show))
if not show:
    print("   готово, блоков:", len(enc))
print()

print("Шифртекст (hex):")
print(to_hex(enc))
print()

with open(FILE, "w", encoding="utf-8") as f:
    f.write("key: " + key + "\n")
    f.write("hex: " + to_hex(enc) + "\n")

print("Ключ и шифртекст сохранены в", FILE)
print("Теперь запустите: python3 decrypt_spn.py")
